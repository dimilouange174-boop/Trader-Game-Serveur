const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: "100kb" }));

const BUGS_FILE = path.join(__dirname, "bugs.json");

const GAME = {
  name: "Trader Game",
  version: "1.1",
  androidVersion: "1.1",
  downloadUrl: "https://example.com/trader-game.apk",
  updateMessage: "Une nouvelle version de Trader Game est disponible !"
};

function readBugs() {
  try {
    if (!fs.existsSync(BUGS_FILE)) return [];
    return JSON.parse(fs.readFileSync(BUGS_FILE, "utf8"));
  } catch {
    return [];
  }
}

function writeBugs(bugs) {
  fs.writeFileSync(BUGS_FILE, JSON.stringify(bugs, null, 2), "utf8");
}

app.get("/", (req, res) => {
  res.json({
    status: "online",
    service: "Trader Game API",
    version: "1.0"
  });
});

app.get("/version", (req, res) => {
  res.json({
    game: GAME.name,
    latestVersion: GAME.version,
    androidVersion: GAME.androidVersion,
    downloadUrl: GAME.downloadUrl,
    updateMessage: GAME.updateMessage
  });
});

app.get("/info", (req, res) => {
  res.json({
    name: GAME.name,
    version: GAME.version,
    platform: "Android",
    virtualMoneyOnly: true,
    description: "Simulation de trading avec argent virtuel."
  });
});

app.post("/bugs", (req, res) => {
  const { description, version, device } = req.body || {};

  if (!description || typeof description !== "string") {
    return res.status(400).json({
      success: false,
      error: "La description du bug est obligatoire."
    });
  }

  const bugs = readBugs();

  const bug = {
    id: Date.now().toString(),
    description: description.trim().slice(0, 5000),
    gameVersion: typeof version === "string" ? version.slice(0, 30) : "inconnue",
    device: typeof device === "string" ? device.slice(0, 100) : "inconnu",
    createdAt: new Date().toISOString()
  };

  bugs.push(bug);
  writeBugs(bugs);

  res.status(201).json({
    success: true,
    message: "Bug reçu. Merci pour ton signalement !",
    bugId: bug.id
  });
});

app.get("/health", (req, res) => {
  res.json({ ok: true });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Trader Game API démarrée sur le port ${PORT}`);
});
