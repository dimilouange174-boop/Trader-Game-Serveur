# Trader Game Server

Petit serveur/API pour Trader Game.

## Fonctionnalités

- `GET /` — état du serveur
- `GET /health` — test de disponibilité
- `GET /version` — dernière version + lien APK
- `GET /info` — informations du jeu
- `POST /bugs` — recevoir un signalement de bug

## Lancer localement

```bash
npm install
npm start
```

Le serveur démarre sur le port 3000.

## Configuration

Ouvre `server.js` et modifie :

```js
version: "1.1",
androidVersion: "1.1",
downloadUrl: "https://example.com/trader-game.apk"
```

Quand tu publies une nouvelle version, change `version` et `androidVersion`, puis mets à jour `downloadUrl`.

## Exemple de signalement

```json
{
  "description": "Le prix de TECHCORP reste bloqué dans Portefeuille.",
  "version": "1.1",
  "device": "Android"
}
```

## Déploiement Render

- Créer un dépôt GitHub et y envoyer ces fichiers.
- Sur Render, créer un nouveau Web Service.
- Sélectionner le dépôt.
- Build Command : `npm install`
- Start Command : `npm start`
- Le serveur écoute automatiquement le port fourni par Render via `process.env.PORT`.

## Important

`bugs.json` convient pour une petite V1/test. Pour un service public avec beaucoup d'utilisateurs, il faudra remplacer ce stockage local par une vraie base de données.
